



$(document).ready(function(){
$('#tabs div').hide(); // Hide all divs
$('.invitegallery').show();
$('#invite').show();
$('#tabs div:first').show(); // Show the first div
$('#tabs ul li:first').addClass('active'); // Set the class of the first link to active
$('#tabs ul li a').click(function(){ //When any link is clicked
$('#tabs ul li').removeClass('active'); // Remove active class from all links
$(this).parent().addClass('active'); //Set clicked link class to active
var currentTab = $(this).attr('href'); // Set variable currentTab to value of href attribute of clicked link
$('#tabs div').hide(); // Hide all divs
$('.gallery').show();
$('.cakegallery').show();
$('.icegallery').show();
$('.invitegallery').show();
$('#header').show();
$('#invite').show();
$('#cake').show();
$('#icecream').show();
$('#hero').show();
$(currentTab).show(); // Show div with id equal to variable currentTab
return false;
});
});




// Wait for the DOM to be ready
$(function() {
  
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  $("form[name='registration']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      name: "required",
      // childname: "required",
      // childage:"required",
      // childgender:"required",
      // date:"required",
      // time:"required",
      address:"required",
      email: {
        required: true,
        email: true
      },
      phone_number: {
        required: true,
        minlength:10,
        maxlength:10
        
        
    
      },
      credit_card_number: {
          required:true,
          minlength:13,
        maxlength:16
          
      
      }
    },
    // Specify validation error messages
    messages: {
      name: "Please enter your name",
      // childname: "Please enter your child's name",
      // childage: "Please enter your child's age",
      // childgender: "Please enter your child's gender",
      // date:"Please enter a date",
      // time:"Please enter a time",
      address: "Please enter your home address",
      email: "Please enter a valid email address",
      phone_number: {
        required: "Please enter a valid phone number",
        minlength:"Please enter a valid phone number",
        maxlength:"Please enter a valid phone number"},
        
      credit_card_number: "Please enter a valid credit card number",
       minlength:"Please enter a valid credit card number",
        maxlength:"Please enter a valid credit card number"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
      
  

   
      
    }
 
  
  });
});

$(document).ready(function() {
  
$('.gallery').cycle({
		fx: 'fade',
	    speed:900,
	    timeout:1800
    
});

$('.cakegallery').cycle({
		fx: 'fade',
	    speed:900,
	    timeout:1800
    
});
$('.icegallery').cycle({
		fx: 'fade',
	    speed:900,
	    timeout:1800
    
});

$('.invitegallery').cycle({
		fx: 'fade',
	    speed:900,
	    timeout:1800
    
});
});


